










public class Feedback {
    private final int correctPosition;
    private final int correctColor;

    public Feedback(int correctPosition, int correctColor) {
        this.correctPosition = correctPosition;
        this.correctColor = correctColor;
    }

    public boolean isCorrect() {
        return correctPosition == 4;
    }

    @Override
    public String toString() {
        return "Correct positions: " + correctPosition + ", Correct colors: " + correctColor;
    }
}

