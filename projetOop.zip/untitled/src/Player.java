




import java.util.Scanner;

public class Player {
    private int attemptsLeft;
    private boolean won;

    public Player() {
        this.attemptsLeft = 10;  // Example number of attempts
        this.won = false;
    }

    public String makeGuess() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your guess (e.g., RGBY): ");
        return scanner.nextLine().toUpperCase();
    }

    public boolean hasAttemptsLeft() {
        return attemptsLeft > 0;
    }

    public boolean hasWon() {
        return won;
    }

    public void setWon(boolean won) {
        this.won = won;
    }

    public void decrementAttempts() {
        attemptsLeft--;
    }
}