














public class Game {
    private Code secretCode;
    private Player player;

    public Game() {
        this.secretCode = new Code();
        this.player = new Player();
    }

    public void start() {
        System.out.println("Welcome to Mastermind!");

        while (!player.hasWon() && player.hasAttemptsLeft()) {
            String guess = player.makeGuess();
            Feedback feedback = secretCode.evaluateGuess(guess);
            System.out.println(feedback);

            if (feedback.isCorrect()) {
                player.setWon(true);
            } else {
                player.decrementAttempts();
            }
        }

        if (player.hasWon()) {
            System.out.println("Congratulations! You've cracked the code.");
        } else {
            System.out.println("Game over! The secret code was: " + secretCode);
        }
    }
}















































