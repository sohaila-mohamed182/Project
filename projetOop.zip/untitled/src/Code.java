

















import java.util.Random;

    public class Code {
        private final String code;

        public Code() {
            this.code = generateRandomCode();
        }

        private String generateRandomCode() {
            char[] colors = {'R', 'G', 'B', 'Y', 'O', 'P'};
            StringBuilder sb = new StringBuilder(4);
            Random random = new Random();
            for (int i = 0; i < 4; i++) {
                sb.append(colors[random.nextInt(colors.length)]);
            }
            return sb.toString();
        }

        public Feedback evaluateGuess(String guess) {
            int correctPosition = 0;
            int correctColor = 0;
            for (int i = 0; i < 4; i++) {
                if (guess.charAt(i) == code.charAt(i)) {
                    correctPosition++;
                } else if (code.indexOf(guess.charAt(i)) != -1) {
                    correctColor++;
                }
            }
            return new Feedback(correctPosition, correctColor);
        }

        @Override
        public String toString() {
            return code;
        }
    }








