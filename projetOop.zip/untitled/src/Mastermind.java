













    public class    Mastermind {

        public static void main(String[] args) {
      Game game = new Game()   ;
      game.start();


        }   }

































